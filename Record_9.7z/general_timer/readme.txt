参考 CSDN博客：MCU开发学习记录9 - 通用定时器学习与实践(HAL库) 
https://chipdynkid.blog.csdn.net/article/details/147313205?spm=1001.2014.3001.5502
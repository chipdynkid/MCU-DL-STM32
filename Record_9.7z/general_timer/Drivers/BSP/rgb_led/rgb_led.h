#ifndef __RGB_LED_H__
#define __RGB_LED_H__

#include "main.h"

void goto_rgb(uint8_t *rgb);
void set_rgb(int red, int green, int blue);

#endif

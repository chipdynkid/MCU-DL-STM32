#ifndef __PWR_H
#define __PWR_H

#include "stm32f4xx.h"
#include "main.h"

void PVD_init(uint32_t pls);

void pwr_enter_sleep(void);
void pwr_enter_stop(void);
void pwr_enter_standby(void);

#endif

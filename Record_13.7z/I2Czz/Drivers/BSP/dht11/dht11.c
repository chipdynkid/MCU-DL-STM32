#include "dht11.h"
#include "delay.h"

static void dht11_start(void)
{
    HAL_GPIO_WritePin(DHT11_GPIO_Port, DHT11_Pin, GPIO_PIN_RESET);
    delay_ms(20);
    HAL_GPIO_WritePin(DHT11_GPIO_Port, DHT11_Pin, GPIO_PIN_SET);
    delay_us(30);
}

static uint8_t dht11_check(void)
{
    uint8_t timeout = 0;

    while (HAL_GPIO_ReadPin(DHT11_GPIO_Port, DHT11_Pin) == GPIO_PIN_SET)
    {
        if (timeout++ > 100)
            return 1;
        delay_us(1);
    }

    timeout = 0;
    while (HAL_GPIO_ReadPin(DHT11_GPIO_Port, DHT11_Pin) == GPIO_PIN_RESET)
    {
        if (timeout++ > 100)
            return 1;
        delay_us(1);
    }

    return 0;
}

static uint8_t dht11_read_bit(void)
{
    uint8_t timeout = 0;
    while ((HAL_GPIO_ReadPin(DHT11_GPIO_Port, DHT11_Pin) == GPIO_PIN_SET) && (timeout++ < 100))
    {
        delay_us(1);
    }
    timeout = 0;
    while ((HAL_GPIO_ReadPin(DHT11_GPIO_Port, DHT11_Pin) == GPIO_PIN_RESET) && (timeout++ < 100))
    {
        delay_us(1);
    }
    delay_us(40);
    if (HAL_GPIO_ReadPin(DHT11_GPIO_Port, DHT11_Pin) == GPIO_PIN_SET)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

static uint8_t dht11_read_byte(void)
{
    uint8_t i;
    uint8_t value = 0;
    for (i = 0; i < 8; i++)
    {
        value <<= 1;
        value |= dht11_read_bit();
    }
    return value;
}

uint8_t dht11_read_data(uint8_t *temp, uint8_t *hum)
{
    uint8_t buf[5] = {0, 0, 0, 0, 0};
    uint8_t i;
    dht11_start();

    if (dht11_check() == 0)
    {
        for (i = 0; i < 5; i++)
        {
            buf[i] = dht11_read_byte();
        }
        if ((buf[0] + buf[1] + buf[2] + buf[3]) == buf[4])
        {
            *hum = buf[0];
            *temp = buf[2];
            return 0;
        }
    }
    else
    {
        return 1;
    }
    return 1;
}

uint8_t dht11_init(void)
{
    dht11_start();
    return dht11_check();
}

#ifndef __BSP_I2C_HARD_H__
#define __BSP_I2C_HARD_H__

#include "main.h"

extern I2C_HandleTypeDef hi2c1;
#define I2C_device hi2c1

//AD0����(9��)�ӵͣ���ʾ0x68Ϊ��ַ��������1λΪ0xd0�����λ��ʾ��дѡ��
#define MPU_ADDR				0X68
#define MPU6050_READ_ADDR     (MPU_ADDR<<1)|1
#define MPU6050_WRITE_ADDR    (MPU_ADDR<<1)|0

#define OLED_ADDR				0X3c
#define OLED_WRITE_ADDR    (OLED_ADDR<<1)|0


uint8_t MPU6050_Hard_Write_Byte(uint8_t reg,uint8_t data);
uint8_t MPU6050_Hard_Read_Byte(uint8_t reg);
uint8_t MPU6050_Hard_Write_Len(uint8_t addr,uint8_t reg,uint8_t len,uint8_t *buf);
uint8_t MPU6050_Hard_Read_Len(uint8_t addr,uint8_t reg,uint8_t len,uint8_t *buf);

uint8_t OLED_Hard_Write_Command(uint8_t data);
uint8_t OLED_Hard_Write_Data(uint8_t cmd);

#endif

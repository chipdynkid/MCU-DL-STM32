#ifndef __BSP_I2C_SOFT_H__
#define __BSP_I2C_SOFT_H__

#include "main.h"

#define i2c_scl(x)                                                                                                                               \
    do                                                                                                                                           \
    {                                                                                                                                            \
        x ? HAL_GPIO_WritePin(I2C_SCL_GPIO_Port, I2C_SCL_Pin, GPIO_PIN_SET) : HAL_GPIO_WritePin(I2C_SCL_GPIO_Port, I2C_SCL_Pin, GPIO_PIN_RESET); \
    } while (0) /* SCL */

#define i2c_sda(x)                                                                                                                               \
    do                                                                                                                                           \
    {                                                                                                                                            \
        x ? HAL_GPIO_WritePin(I2C_SDA_GPIO_Port, I2C_SDA_Pin, GPIO_PIN_SET) : HAL_GPIO_WritePin(I2C_SDA_GPIO_Port, I2C_SDA_Pin, GPIO_PIN_RESET); \
    } while (0) /* SDA */

#define i2c_read_sda() HAL_GPIO_ReadPin(I2C_SDA_GPIO_Port, I2C_SDA_Pin) /* SDA */

void i2c_start(void);
void i2c_stop(void);
void i2c_ack(void);
void i2c_nack(void);
uint8_t i2c_wait_ack(void);
void i2c_send_byte(uint8_t txd);
uint8_t i2c_read_byte(uint8_t ack);

#endif

#ifndef __BSP_096OLED_H__
#define __BSP_096OLED_H__

#include "main.h"

// ģʽѡ��
#define OLED_SOFT_I2C 0 // ����IIC
#define OLED_HARD_I2C 1 // Ӳ��IIC

#define OLED_ADDRESS 0x3C              // OLED IIC��ַ
#define OLED_WRITE_ADDRESS ((0x3C << 1) | 0) // OLED д��ַ

#define OLED_CMD 0x00  // ����
#define OLED_DATA 0x01 // ����

void oled_init(void);                                   // OLED��ʼ��
void oled_clear(void);                                  // OLED����
void oled_clear_row(uint8_t x1, uint8_t x2, uint8_t y); // OLED����
void oled_display_on(void);                             // OLED��ʾ��
void oled_display_off(void);                            // OLED��ʾ��
void oled_fill(void);                                   // OLEDȫ��
void oled_set_pos(uint8_t x, uint8_t y);                // OLED���ù��λ��
void oled_refresh_gram(void);                           // OLEDˢ��GRAM

void oled_draw_point(uint8_t x, uint8_t y, uint8_t dot);
void oled_write_byte(uint8_t data, uint8_t mode);
void oled_show_char(uint8_t x, uint8_t y, uint8_t chr, uint8_t size);                                              // OLED��ʾһ���ַ�
void oled_show_string(uint8_t x, uint8_t y, uint8_t *str, uint8_t size);                                           // OLED��ʾ�ַ���
void oled_show_num(uint8_t x, uint8_t y, uint32_t num, uint8_t len, uint8_t size);                                 // OLED��ʾ����
void oled_show_chinese(uint8_t x, uint8_t y, uint8_t number);                                                      // OLED��ʾ����16*16
void oled_show_picture(uint8_t x, uint8_t y_all, uint8_t width, uint8_t height, const uint8_t *pic, uint8_t mode); // OLED��ʾͼƬ

#endif

#ifndef __BSP_SPI_HARDWARE_H
#define __BSP_SPI_HARDWARE_H

#include "main.h"

#define W25QXX_HARD_SPI 1 // Ӳ��IIC
#define TOUCH_HARD_SPI 0 // Ӳ��IIC

#if (W25QXX_HARD_SPI || TOUCH_HARD_SPI) 


/* CS */
#define SPI_CS1(x)   do{ x ? \
                      HAL_GPIO_WritePin(SPI_CS1_GPIO_Port, SPI_CS1_Pin, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(SPI_CS1_GPIO_Port, SPI_CS1_Pin, GPIO_PIN_RESET); \
                     }while(0)



void bsp_spi_hard_init(void);
void bsp_spi_hard_start(void);
void bsp_spi_hard_stop(void);
uint8_t bsp_spi_hard_SwapByte(uint8_t ByteSend);

#endif

#endif

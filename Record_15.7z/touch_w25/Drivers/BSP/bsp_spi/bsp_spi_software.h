#ifndef __BSP_SPI_SOFTWARE_H
#define __BSP_SPI_SOFTWARE_H

#include "main.h"

#define W25QXX_SOFT_SPI 0 // ����IIC
#define TOUCH_SOFT_SPI 1 // ����IIC

#if (W25QXX_SOFT_SPI || TOUCH_SOFT_SPI) 

/* CS */
#define SPI_CS2(x)   do{ x ? \
                      HAL_GPIO_WritePin(SPI_CS2_GPIO_Port, SPI_CS2_Pin, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(SPI_CS2_GPIO_Port, SPI_CS2_Pin, GPIO_PIN_RESET); \
                     }while(0)

/* SCK */
#define SPI_SCK(x)   do{ x ? \
                      HAL_GPIO_WritePin(SPI_SCK_GPIO_Port, SPI_SCK_Pin, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(SPI_SCK_GPIO_Port, SPI_SCK_Pin, GPIO_PIN_RESET); \
                     }while(0)

/* MOSI */
#define SPI_MOSI(x)   do{ x ? \
                      HAL_GPIO_WritePin(SPI_MOSI_GPIO_Port, SPI_MOSI_Pin, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(SPI_MOSI_GPIO_Port, SPI_MOSI_Pin, GPIO_PIN_RESET); \
                     }while(0)

/* MISO */
#define SPI_MISO()   HAL_GPIO_ReadPin(SPI_MISO_GPIO_Port, SPI_MISO_Pin)

void bsp_spi_soft_init(void);
void bsp_spi_soft_start(void);
void bsp_spi_soft_stop(void);
uint8_t bsp_spi_soft_SwapByte(uint8_t ByteSend);

#endif

#if TOUCH_SOFT_SPI
/* MISO */
#define SPI_PEN()   HAL_GPIO_ReadPin(SPI_PEN_GPIO_Port, SPI_PEN_Pin)

#endif

#endif

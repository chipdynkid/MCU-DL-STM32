/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "rtc.h"
#include "usart.h"
#include "gpio.h"
#include "fsmc.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "delay.h"
#include "stdio.h"
#include "string.h"
#include "bsp_lcd_fsmc.h"
#include "lcd_picture.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
extern uint8_t write_bakcup_state;
extern RTC_HandleTypeDef hrtc;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void write_bakcup(void);
void read_bakcup(void);
void RTC_LoadFromBKUP(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
    uint8_t key_val = 0;
    uint8_t lcd_id[12];
    uint32_t iniRTC = 0x01;

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_FSMC_Init();
  MX_RTC_Init();
  /* USER CODE BEGIN 2 */
    delay_init(168);
    lcd_init();

    sprintf((char *)lcd_id, "LCD ID:%04X", lcddev.id); /* ��LCD ID��ӡ��lcd_id���� */
    // lcd_show_string(10, 40, 240, 32, 32, "STM32", RED);
    // lcd_show_string(10, 80, 240, 24, 24, "TFTLCD TEST", RED);
    // lcd_show_string(10, 110, 240, 16, 16, "ATOM@ALIENTEK", RED);
    lcd_show_string(10, 10, 240, 16, 16, (char *)lcd_id, RED); /* ��ʾLCD ID */
                                                               // lcd_show_chinese(10, 50, 0, 16, 1, BLACK);
                                                               // lcd_show_chinese(30, 50, 1, 16, 1, BLACK);
                                                               // lcd_show_chinese(50, 50, 2, 16, 1, BLACK);
                                                               // lcd_show_chinese(100, 50, 0, 24, 1, RED);
                                                               // lcd_show_chinese(160, 50, 0, 32, 1, RED);
                                                               // lcd_show_image(40, 150, 121, 64, (uint16_t *)Image_1);
    
    iniRTC = HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR0);
    if ((iniRTC & 0x01) == 0)
    {
        lcd_show_string(0, 150, 240, 16, 16, "Reset RTC time on startup: Yes", RED);
    }
    else
    {
        lcd_show_string(0, 150, 240, 16, 16, "Reset RTC time on startup: No ", RED);
    }
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    while (1)
    {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

        key_val = key_scan(0);
        if (key_val == 1)
        {
            iniRTC = ! iniRTC;
            if (write_bakcup_state == 1)
            {
                write_bakcup();
                
                HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR0, iniRTC); // 0x01=������ʱ��ı�־
            }
            read_bakcup();
        }
        else if (key_val == 2)
        {

            // uint32_t iniRTC = HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR0);
            // iniRTC = 0x01;
            // if ((iniRTC & 0x01) != 0)
            // {
            //     lcd_show_string(0, 300, 240, 16, 16, "Reset RTC time on startup    ", RED);
            // }
            // else
            // {
            //     lcd_show_string(0, 300, 240, 16, 16, "Not reset RTC time on startup", RED);
            // }
            // HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR0, iniRTC);

            RTC_LoadFromBKUP();
        }
    }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE|RCC_OSCILLATORTYPE_LSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void write_bakcup(void)
{
    RTC_TimeTypeDef sTime;
    RTC_DateTypeDef sDate;
    // __HAL_RTC_TAMPER_CLEAR_FLAG(&hrtc, RTC_FLAG_TAMP1F);
    if (HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN) == HAL_OK)
    {
        HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);

        // __HAL_RTC_TAMPER_CLEAR_FLAG(&hrtc, RTC_FLAG_TAMP1F);
        
        HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR1, 0x01); // 0x01=������ʱ��ı�־
        HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR2, sTime.Hours); // ʹ��ȫ�ֱ���sTime�����ٶ�ȡ��ǰʱ��
        HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR3, sTime.Minutes);
        HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR4, sTime.Seconds);
        // sTime.Hours--;
        // HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN);

        char timeStr[30];
        sprintf(timeStr, "Bakcup OK!:%2d:%2d:%2d", sTime.Hours, sTime.Minutes, sTime.Seconds); // ת��Ϊ�ַ���,�Զ�����"\0"

        lcd_show_string(10, 130, strlen(timeStr) * 16, 16, 16, timeStr, RED);
        write_bakcup_state = 0;
    }
}

void read_bakcup(void)
{
    uint32_t regValue;
    char str[40];
    // __HAL_RTC_TAMPER_CLEAR_FLAG(&hrtc, RTC_FLAG_TAMP1F);
    regValue = HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR0);
    sprintf(str, "Reset RTC, BKP_DR0 = %lu", regValue);
    lcd_show_string(0, 170, 240, 16, 16, str, RED);

    regValue = HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR1);
    sprintf(str, "Time is saved, BKP_DR1 = %lu", regValue);
    lcd_show_string(0, 190, 240, 16, 16, str, RED);

    regValue = HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR2);
    sprintf(str, "Saved time (Hour), BKP_DR2 = %lu", regValue);
    lcd_show_string(0, 210, 240, 16, 16, str, RED);

    regValue = HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR3);
    sprintf(str, "Saved time (Min), BKP_DR3 = %lu", regValue);
    lcd_show_string(0, 230, 240, 16, 16, str, RED);

    regValue = HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR4);
    sprintf(str, "Saved time (Sec), BKP_DR4 = %lu", regValue);
    lcd_show_string(0, 250, 240, 16, 16, str, RED);

    // uint32_t value[4]={10,10,10,10};
    // char str[40];

    // value[0] = HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR1);
    // value[1] = HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR2);
    // value[2] = HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR3);
    // value[3] = HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR4);
    //     delay_ms(10);
    // sprintf(str, "BK_value = %lu,%lu,%lu,%lu", value[0], value[1], value[2], value[3]);
    // lcd_show_string(10, 150, strlen(str) * 16, 16, 16, str, RED);
}

void RTC_LoadFromBKUP(void)
{
    // __HAL_RTC_TAMPER_CLEAR_FLAG(&hrtc, RTC_FLAG_TAMP1F);
    if (HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR1))
    {
        RTC_TimeTypeDef sTime = {0};
        // __HAL_RTC_TAMPER_CLEAR_FLAG(&hrtc, RTC_FLAG_TAMP1F);
        sTime.Hours = HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR2);
        sTime.Minutes = HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR3);
        sTime.Seconds = HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR4);
        delay_ms(10);
        lcd_fill(0, 170, 320, 270, WHITE);
        // __HAL_RTC_TAMPER_CLEAR_FLAG(&hrtc, RTC_FLAG_TAMP1F);
        if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN) == HAL_OK)
        {
            lcd_show_string(0, 170, 240, 16, 16, "Load BKUP time, success", RED);
        }
        else
        {
            lcd_show_string(0, 170, 240, 16, 16, "Load BKUP time, error", RED);
        }
    }
    else
    {
        lcd_show_string(0, 170, 240, 16, 16, "No BKUP time is saved", RED);
    }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
    /* User can add his own implementation to report the HAL error return state */
    __disable_irq();
    while (1)
    {
    }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
    /* User can add his own implementation to report the file name and line number,
       ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

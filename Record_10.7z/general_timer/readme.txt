参考 CSDN博客：MCU开发学习记录10 - 高级定时器学习与实践(HAL库) 
https://blog.csdn.net/weixin_45483813/article/details/147378570?spm=1001.2014.3001.5501
#include "adc_deal.h"

extern ADC_HandleTypeDef hadc1;

// ������ѯ
//  adc_bits: 12, 10, 8
uint32_t adc_get_poll(ADC_HandleTypeDef *hadc, uint8_t adc_bits, uint8_t times)
{
    uint32_t temp = 0;
    uint8_t i;
    for (i = 0; i < times; i++)
    {

        HAL_ADC_Start(hadc);                 /* ����ADC */
        HAL_ADC_PollForConversion(hadc, 10); /* ��ѯת�� */

        uint32_t adc_value = HAL_ADC_GetValue(hadc); /* �������һ��ADC1�������ת����� */

        if (adc_bits == 12)
        {
            temp += adc_value & 0x0FFF;
        }
        else if (adc_bits == 10)
        {
            temp += adc_value & 0x03FF;
        }
        else if (adc_bits == 8)
        {
            temp += adc_value & 0x00FF;
        }
    }

    return temp / times;
}

uint16_t adc_get_intemp(uint32_t adc_value)
{

    float temp = (float)adc_value * (3.3 / 4096);
    // �¶ȣ���λΪ ��C��= {(VSENSE �� V25) / Avg_Slope} + 25
    temp = (temp - 0.76f) / 0.0025f + 25;
    uint16_t temp_end = temp * 100;
    return temp_end;
}

uint16_t adc_deal(uint16_t adc_value)
{
    float temp = (float)adc_value * (3.3 / 4096);
    uint16_t temp_end = temp * 100;
    return temp_end;
}

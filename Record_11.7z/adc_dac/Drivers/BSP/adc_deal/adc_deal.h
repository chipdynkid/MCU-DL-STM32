#ifndef __ADC_DEAL_H__
#define __ADC_DEAL_H__

#include "main.h"

uint32_t adc_get_poll(ADC_HandleTypeDef *hadc, uint8_t adc_bits, uint8_t times);
uint16_t adc_get_intemp(uint32_t adc_value);
uint16_t adc_deal(uint16_t adc_value);

#endif

#include "rgb_led.h"

//extern TIM_HandleTypeDef htim5;
extern UART_HandleTypeDef huart2;

static uint8_t hex_char_to_int(uint8_t c)
{
    if (c >= '0' && c <= '9')
    {
        return c - '0'; // �����ַ�ת0-9
    }
    else if (c >= 'A' && c <= 'F')
    {
        return 10 + (c - 'A'); // ��д��ĸת10-15
    }
    else if (c >= 'a' && c <= 'f')
    {
        return 10 + (c - 'a'); // Сд��ĸת10-15
    }
    return 0; // �Ƿ��ַ�Ĭ�Ϸ���0�����Զ����������
}
void goto_rgb(uint8_t *rgb)
{
    int red, green, blue;
    red = hex_char_to_int(rgb[0]) * 16 + hex_char_to_int(rgb[1]);
    green = hex_char_to_int(rgb[2]) * 16 + hex_char_to_int(rgb[3]);
    blue = hex_char_to_int(rgb[4]) * 16 + hex_char_to_int(rgb[5]);
    set_rgb(red, green, blue);
}
void set_rgb(int red, int green, int blue)
{
//    __HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_2, 42000 * red / 255);
//    __HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_3, 42000 * blue / 255);
//    __HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_4, 42000 * green / 255);
}

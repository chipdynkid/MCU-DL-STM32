参考 CSDN博客：MCU开发学习记录2 - MDK工程文件搭建(HAL库)
https://blog.csdn.net/weixin_45483813/article/details/147003269?spm=1001.2014.3001.5501
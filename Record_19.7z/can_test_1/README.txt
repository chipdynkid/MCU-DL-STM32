参考 CSDN博客：MCU开发学习记录19* - MCU开发学习记录14* - CAN学习与实践(HAL库) - 三节点之间互相通信
https://chipdynkid.blog.csdn.net/article/details/148011008?spm=1001.2014.3001.5502
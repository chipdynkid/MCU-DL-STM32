/*
 * mycan.c
 *
 * Created: 2025-05-11 15:02:23
 * Author: user
 *  function:  CANͨ������������� - ����
 *
 */

#include "mycan.h"
#include "can.h"
#include "bsp_lcd_fsmc.h"
#include "stdio.h"

extern CAN_HandleTypeDef hcan1;
uint8_t can_fifo0_status = 0;
extern uint32_t RxID;
extern uint8_t RxLength;
extern uint8_t RxData[8];

HAL_StatusTypeDef MyCAN_SetFilters(void)
{
    CAN_FilterTypeDef canFilter;
    canFilter.FilterBank = 0;
    canFilter.FilterMode = CAN_FILTERMODE_IDMASK;
    canFilter.FilterScale = CAN_FILTERSCALE_32BIT;

    canFilter.FilterIdHigh = 0x0000;
    canFilter.FilterIdLow = 0x0000;
    canFilter.FilterMaskIdHigh = 0x0000;
    canFilter.FilterMaskIdLow = 0x0000;

    canFilter.FilterFIFOAssignment = CAN_FILTER_FIFO0;
    canFilter.FilterActivation = CAN_FILTER_ENABLE;
    HAL_StatusTypeDef result = HAL_CAN_ConfigFilter(&hcan1, &canFilter);
    return result;
}

uint8_t MyCAN_ReceiveFlag(void)
{
    if (HAL_CAN_GetRxFifoFillLevel(&hcan1, CAN_RX_FIFO0) > 0)
    {
        return 1;
    }
    return 0;
}

void MyCAN_Transmit(uint32_t ID, uint8_t Length, uint8_t *Data, uint8_t frameType)
{
    CAN_TxHeaderTypeDef TxMessage;
    TxMessage.StdId = ID;
    TxMessage.ExtId = ID;
    TxMessage.IDE = frameType;
    TxMessage.RTR = CAN_RTR_DATA;
    TxMessage.DLC = Length;
    TxMessage.TransmitGlobalTime = DISABLE;

    uint8_t TxData[Length];
    for (int i = 0; i < Length; i++)
    {
        TxData[i] = Data[i];
    }

    uint32_t TxMailbox;
    uint32_t Timeout = 0;
    uint8_t tempStr[30];

    while (HAL_CAN_GetTxMailboxesFreeLevel(&hcan1) < 1)
    {
        Timeout++;
        if (Timeout > 100000)
        {
            break;
        }
    }

    if (HAL_CAN_AddTxMessage(&hcan1, &TxMessage, TxData, &TxMailbox) != HAL_OK)
    {
        lcd_show_string(10, 30, 240, 16, 16, "Send to mailbox error", RED);
        return;
    }
    sprintf((char *)tempStr, "Send MsgID = %4X", ID);
    lcd_show_string(10, 30, 240, 16, 16, (char *)tempStr, RED);
}

void MyCAN_Receive(uint32_t *ID, uint8_t *Length, uint8_t *Data)
{
    uint8_t tempStr[30];

    if (HAL_CAN_GetRxFifoFillLevel(&hcan1, CAN_RX_FIFO0) != 1)
    {
        lcd_show_string(10, 50, 240, 16, 16, "Send to mailbox error", RED);
        return;
    }

    CAN_RxHeaderTypeDef RxMessage;

    if (HAL_CAN_GetRxMessage(&hcan1, CAN_RX_FIFO0, &RxMessage, Data) == HAL_OK)
    {

        if (RxMessage.IDE == CAN_ID_STD)
        {
            *ID = RxMessage.StdId;
        }
        else
        {
            *ID = RxMessage.ExtId;
        }
        sprintf((char *)tempStr, "Rece MsgID = %4X", *ID);
        lcd_show_string(10, 50, 240, 16, 16, (char *)tempStr, RED);
        *Length = RxMessage.DLC;
        // if (RxMessage.RTR == CAN_RTR_DATA)
        // {
        //     *Length = RxMessage.DLC;
        //     for (uint8_t i = 0; i < *Length; i++)
        //     {
        //         Data[i] = RxMessage.Data[i];
        //     }
        // }
        // else
        // {
        //     //...
        // }
    }
}

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    MyCAN_Receive(&RxID, &RxLength, RxData);
    can_fifo0_status = 1;
}

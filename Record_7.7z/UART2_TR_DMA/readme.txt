参考 CSDN博客：MCU开发学习记录7 - DMA学习与实践(HAL库)
https://mpbeta.csdn.net/mp_blog/creation/editor/147165198?spm=1001.2014.3001.5352
参考 CSDN博客：MCU开发学习记录5 - 中断学习与实践(HAL库)
https://blog.csdn.net/weixin_45483813/article/details/147033503
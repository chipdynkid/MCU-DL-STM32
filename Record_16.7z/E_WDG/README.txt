参考 CSDN博客：MCU开发学习记录14* - MCU开发学习记录16* - 看门狗学习与实践(HAL库)
https://chipdynkid.blog.csdn.net/article/details/147993867?spm=1001.2014.3001.5502
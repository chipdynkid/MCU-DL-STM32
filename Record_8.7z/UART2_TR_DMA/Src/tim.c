/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file    tim.c
 * @brief   This file provides code for the configuration
 *          of the TIM instances.
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "tim.h"

/* USER CODE BEGIN 0 */
#include "gpio.h"
#include "usart.h"
extern uint32_t cntt;
/* USER CODE END 0 */

TIM_HandleTypeDef htim6;
DMA_HandleTypeDef hdma_tim6_up;

/* TIM6 init function */
void MX_TIM6_Init(void)
{

    /* USER CODE BEGIN TIM6_Init 0 */

    /* USER CODE END TIM6_Init 0 */

    TIM_MasterConfigTypeDef sMasterConfig = {0};

    /* USER CODE BEGIN TIM6_Init 1 */

    /* USER CODE END TIM6_Init 1 */
    htim6.Instance = TIM6;
    htim6.Init.Prescaler = 8399;
    htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim6.Init.Period = 9999;
    htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
    if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
    {
        Error_Handler();
    }
    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
    {
        Error_Handler();
    }
    /* USER CODE BEGIN TIM6_Init 2 */

    /* USER CODE END TIM6_Init 2 */
}

void HAL_TIM_Base_MspInit(TIM_HandleTypeDef *tim_baseHandle)
{

    if (tim_baseHandle->Instance == TIM6)
    {
        /* USER CODE BEGIN TIM6_MspInit 0 */

        /* USER CODE END TIM6_MspInit 0 */
        /* TIM6 clock enable */
        __HAL_RCC_TIM6_CLK_ENABLE();

        /* TIM6 DMA Init */
        /* TIM6_UP Init */
        hdma_tim6_up.Instance = DMA1_Stream1;
        hdma_tim6_up.Init.Channel = DMA_CHANNEL_7;
        hdma_tim6_up.Init.Direction = DMA_MEMORY_TO_PERIPH;
        hdma_tim6_up.Init.PeriphInc = DMA_PINC_DISABLE;
        hdma_tim6_up.Init.MemInc = DMA_MINC_ENABLE;
        hdma_tim6_up.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
        hdma_tim6_up.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
        hdma_tim6_up.Init.Mode = DMA_CIRCULAR;
        hdma_tim6_up.Init.Priority = DMA_PRIORITY_MEDIUM;
        hdma_tim6_up.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
        if (HAL_DMA_Init(&hdma_tim6_up) != HAL_OK)
        {
            Error_Handler();
        }

        __HAL_LINKDMA(tim_baseHandle, hdma[TIM_DMA_ID_UPDATE], hdma_tim6_up);

        /* TIM6 interrupt Init */
        HAL_NVIC_SetPriority(TIM6_DAC_IRQn, 2, 2);
        HAL_NVIC_EnableIRQ(TIM6_DAC_IRQn);
        /* USER CODE BEGIN TIM6_MspInit 1 */

        /* USER CODE END TIM6_MspInit 1 */
    }
}

void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef *tim_baseHandle)
{

    if (tim_baseHandle->Instance == TIM6)
    {
        /* USER CODE BEGIN TIM6_MspDeInit 0 */

        /* USER CODE END TIM6_MspDeInit 0 */
        /* Peripheral clock disable */
        __HAL_RCC_TIM6_CLK_DISABLE();

        /* TIM6 DMA DeInit */
        HAL_DMA_DeInit(tim_baseHandle->hdma[TIM_DMA_ID_UPDATE]);

        /* TIM6 interrupt Deinit */
        HAL_NVIC_DisableIRQ(TIM6_DAC_IRQn);
        /* USER CODE BEGIN TIM6_MspDeInit 1 */

        /* USER CODE END TIM6_MspDeInit 1 */
    }
}

/* USER CODE BEGIN 1 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM6)
    {
        // DMA��ʽ�޸�ARRֵ
        if (cntt < 30000)
        {
            cntt += 1000;
        }
        else
        {
            cntt = 9999;
        }
        // DMAѡ�񵥴δ���ģʽ��Ҫ�ظ�����
        // HAL_TIM_Base_Start_DMA(&htim6, &cntt, 1);

        // �жϷ�ʽ�޸�ARRֵ
        __HAL_TIM_SET_AUTORELOAD(&htim6, cntt);
        HAL_UART_Transmit_DMA(&huart2, (uint8_t *)"goin1", 5);
        HAL_GPIO_TogglePin(LED0_GPIO_Port, LED0_Pin);
    }
}

// void HAL_TIM_PeriodElapsedHalfCpltCallback(TIM_HandleTypeDef *htim)
// {
//     if (htim->Instance == TIM6) /* ����Ƕ�ʱ��6 */
//     {
//         HAL_GPIO_TogglePin(LED0_GPIO_Port, LED0_Pin);
//     }
// }

/* USER CODE END 1 */

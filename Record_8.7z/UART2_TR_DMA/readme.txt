参考 CSDN博客：MCU开发学习记录8 - 基本定时器学习与实践(HAL库)
https://chipdynkid.blog.csdn.net/article/details/147228906?spm=1001.2014.3001.5502